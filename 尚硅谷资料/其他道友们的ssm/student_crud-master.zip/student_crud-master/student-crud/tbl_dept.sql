/*
SQLyog Ultimate v13.1.1 (64 bit)
MySQL - 8.0.16 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `tbl_dept` (
	`dept_id` int (11),
	`dept_name` varchar (765)
); 
insert into `tbl_dept` (`dept_id`, `dept_name`) values('1','学生部');
insert into `tbl_dept` (`dept_id`, `dept_name`) values('2','信息部');
insert into `tbl_dept` (`dept_id`, `dept_name`) values('3','记者部');
insert into `tbl_dept` (`dept_id`, `dept_name`) values('4','实创部');
